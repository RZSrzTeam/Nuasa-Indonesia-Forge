
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.rzzastudio.nuasaindonesiamod.init;

import net.rzzastudio.nuasaindonesiamod.block.BlockindonesiaBlock;
import net.rzzastudio.nuasaindonesiamod.NuasaIndonesiaModMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

public class NuasaIndonesiaModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, NuasaIndonesiaModMod.MODID);
	public static final RegistryObject<Block> BLOCKINDONESIA = REGISTRY.register("blockindonesia", () -> new BlockindonesiaBlock());
}
