
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.rzzastudio.nuasaindonesiamod.init;

import net.rzzastudio.nuasaindonesiamod.item.TujupuluhlimariburupiahItem;
import net.rzzastudio.nuasaindonesiamod.item.SepuluhriburupiahItem;
import net.rzzastudio.nuasaindonesiamod.item.MisedapItem;
import net.rzzastudio.nuasaindonesiamod.item.LimaruburupiahItem;
import net.rzzastudio.nuasaindonesiamod.item.DuariburupiahItem;
import net.rzzastudio.nuasaindonesiamod.item.DuapuluhriburupiahItem;
import net.rzzastudio.nuasaindonesiamod.item.AirmendidihItem;
import net.rzzastudio.nuasaindonesiamod.NuasaIndonesiaModMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

public class NuasaIndonesiaModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, NuasaIndonesiaModMod.MODID);
	public static final RegistryObject<Item> BLOCKINDONESIA = block(NuasaIndonesiaModModBlocks.BLOCKINDONESIA, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MISEDAP = REGISTRY.register("misedap", () -> new MisedapItem());
	public static final RegistryObject<Item> AIRMENDIDIH = REGISTRY.register("airmendidih", () -> new AirmendidihItem());
	public static final RegistryObject<Item> DUARIBURUPIAH = REGISTRY.register("duariburupiah", () -> new DuariburupiahItem());
	public static final RegistryObject<Item> LIMARUBURUPIAH = REGISTRY.register("limaruburupiah", () -> new LimaruburupiahItem());
	public static final RegistryObject<Item> SEPULUHRIBURUPIAH = REGISTRY.register("sepuluhriburupiah", () -> new SepuluhriburupiahItem());
	public static final RegistryObject<Item> DUAPULUHRIBURUPIAH = REGISTRY.register("duapuluhriburupiah", () -> new DuapuluhriburupiahItem());
	public static final RegistryObject<Item> TUJUPULUHLIMARIBURUPIAH = REGISTRY.register("tujupuluhlimariburupiah",
			() -> new TujupuluhlimariburupiahItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
