
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.rzzastudio.nuasaindonesiamod.init;

import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class NuasaIndonesiaModModTrades {
}
